print("Hello World! It's a beautiful Day.")
